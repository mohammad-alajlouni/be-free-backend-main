import { Controller } from '@nestjs/common';

@Controller('app')
export class AppController {}
