export enum MaritalStatus {
  SINGLE = 1,
  MARRIED,
  DIVORCED,
  WIDOWED,
}
