export enum OTPChannel {
  WHATSAPP = 1,
  SMS,
}
