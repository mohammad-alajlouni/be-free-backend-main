export enum UserRole {
  PSYCHOLOGIST = 1,
  PATIENT,
  ADMIN,
}
