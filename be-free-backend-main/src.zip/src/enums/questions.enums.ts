export enum QuestionStatus {
  ANSWERED = 1,
  NOT_ANSWERED,
}
