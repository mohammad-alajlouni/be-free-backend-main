export enum RatingOptions {
  VERY_BAD = 1,
  BAD,
  AVERAGE,
  GOOD,
  VERY_GOOD,
}
