import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { OTPChannel } from 'src/enums/otp.enums';
import { Twilio } from 'twilio';

@Injectable()
export class TwilioService {
  private client: Twilio;

  constructor() {
    this.client = new Twilio(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_AUTH_TOKEN,
    );
  }

  async sendOtp(
    mobile: string,
    otp: string,
    channel: OTPChannel,
  ): Promise<void> {
    const from =
      channel === OTPChannel.WHATSAPP
        ? `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER}`
        : process.env.TWILIO_PHONE_NUMBER;

    const to = channel === OTPChannel.WHATSAPP ? `whatsapp:${mobile}` : mobile;

    const messageOptions = {
      from,
      to,
      ...(channel === OTPChannel.WHATSAPP
        ? {
            contentSid: process.env.TWILIO_CONTENT_SID,
            contentVariables: JSON.stringify({
              '1': `Your Be Free OTP is ${otp}`,
            }),
          }
        : {
            body: `Your Be Free OTP is ${otp}`,
          }),
    };

    try {
      await this.client.messages.create(messageOptions);
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to send OTP',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
