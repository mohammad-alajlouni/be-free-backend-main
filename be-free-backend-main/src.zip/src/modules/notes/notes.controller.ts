import { Controller } from '@nestjs/common';

@Controller('notes')
export class NotesController {}
