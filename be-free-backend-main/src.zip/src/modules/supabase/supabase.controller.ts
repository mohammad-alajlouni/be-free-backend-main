import { Controller } from '@nestjs/common';

@Controller('supabase')
export class SupabaseController {}
