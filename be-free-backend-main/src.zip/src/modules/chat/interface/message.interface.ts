export interface MessageInterface {
  _id: string;
  content: string;
  roomId: string;
  ownerID: string;
}
